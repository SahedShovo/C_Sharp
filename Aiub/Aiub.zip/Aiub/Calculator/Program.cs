﻿namespace Calculator
{
    class Program {
        static void Main(string[] args){
            int a,b;
            char c,o;
            do{
                Console.WriteLine($"Enter a Equation :");
                string [] value = Console.ReadLine().Split();
                a=int.Parse(value[0]);
                o=char.Parse(value[1]);
                b=int.Parse(value[2]);
                switch (o)
                {
                    case '+':
                    Console.WriteLine($"{a}  {o}   {b} : {a+b}");
                    break;
                    case '-':
                    Console.WriteLine($"{a}  {o}   {b} : {a-b}");
                    break;
                    case '*':
                    Console.WriteLine($"{a}  {o}   {b} : {a*b}");
                    break;
                    case '/':
                    Console.WriteLine($"{a}  {o}   {b} : {a/b}");
                    break;
                    case '%':
                    Console.WriteLine($"{a}  {o}   {b} : {a%b}");
                    break;

                    default:
                    Console.WriteLine($"Invalid Operation !");
                    break ;
                    
                }
                Console.Write($"Choice :");
                c=char.Parse(Console.ReadLine());
            }
            while (c=='y');
        }
    }
}