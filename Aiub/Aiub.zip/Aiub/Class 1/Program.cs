﻿using System;

public class Program
{
    public static void Main(string[] args)
    {
        Console.WriteLine("Hello World!");
        
        int mynumber = 10;
        Console.WriteLine("Number: " + mynumber);
        Console.WriteLine(5 + 7);
        
        Console.Write("Enter your name: ");
        string name = Console.ReadLine();
        Console.WriteLine("Name: " + name);

        Console.Write("Enter your CGPA: ");
        double cgpa = Convert.ToDouble(Console.ReadLine());
        Console.WriteLine("CGPA: " + cgpa);

        if (mynumber == 10)
        {
            Console.WriteLine("Number is 10");
        }
        else
        {
            Console.WriteLine("Number is not 10");
        }

        switch (mynumber)
        {
            case 10:
                Console.WriteLine("Number is 10");
                break;
            case 20:
                Console.WriteLine("Number is 20");
                break;
            default:
                Console.WriteLine("Number is not 10 or 20");
                break;
        }
        for (int i = 0; i < 5; i++)
        {
            Console.WriteLine("sl:"+(i + 1));
        }
        int n=10;
        while (n>=10)
        {
            Console.WriteLine($"Re:"+n);
            n--;            
        }
        Console.WriteLine($"Int Input: ");
        
        int a= int.Parse(Console.RedLine());
        Console.WriteLine(a);
        
        
    }
}
