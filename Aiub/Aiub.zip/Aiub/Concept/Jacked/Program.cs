﻿using System;
class Program{
    static void Main(){
       int [][] j =new int[][]
       {
        new int[] {1,2},
        new int[]{3,4,5},
        new int[]{6,7}
       };
       foreach (var item in j)
       {
        foreach (var i in item)
        {
            Console.Write($"{i} ");
        }
       Console.WriteLine($"");
       }
    }
}