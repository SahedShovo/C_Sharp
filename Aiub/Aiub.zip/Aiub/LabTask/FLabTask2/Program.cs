﻿using System;
using System.Collections.Generic;

public class Student
{
    public string Name { get; set; }

    public Student(string name)
    {
        Name = name;
    }
}
public class Teacher
{
    public string Name { get; set; }
    public List<Student> Students { get; set; }

    public Teacher(string name)
    {
        Name = name;
        Students = new List<Student>();
    }

    public void AddStudent(Student student)
    {
        Students.Add(student);
    }

    public void DisplayStudents()
    {
        Console.WriteLine($"{Name}'s students:");
        foreach (var student in Students)
        {
            Console.WriteLine($"- {student.Name}");
        }
    }
}

class Program
{
    static void Main()
    {
        Teacher teacher = new Teacher("Mr. Smith");

        Student student1 = new Student("Alice");
        Student student2 = new Student("Bob");

        teacher.AddStudent(student1);
        teacher.AddStudent(student2);

        teacher.DisplayStudents();
    }
}
