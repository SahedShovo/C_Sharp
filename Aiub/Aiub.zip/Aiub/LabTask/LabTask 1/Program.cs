﻿using System;

class Car
{
   
    private string brand;
    private string model;
    private int year;
    private string type;

    public void SetBrand(string b) { brand = b; }
    public void SetModel(string m) { model = m; }
    public void SetYear(int y) { year = y; }
    public void SetType(string t) { type = t; }

    
    public string GetBrand() { return brand; }
    public string GetModel() { return model; }
    public int GetYear() { return year; }
    public string GetType() { return type; }

    
    public Car(string b, string m, int y, string t)
    {
        SetBrand(b);
        SetModel(m);
        SetYear(y);
        SetType(t);
    }

    public void DisplayCar()
    {
        Console.WriteLine($"Brand: {GetBrand()}, Model: {GetModel()}, Year: {GetYear()}, Type: {GetType()}");
    }
}

class CarCollection
{
    private Car[] cars = new Car[100];
    private int count = 0; 

    public void AddCar(string brand, string model, int year, string type)
    {
        if (count < cars.Length)
        {
            cars[count] = new Car(brand, model, year, type);
            count++;
            Console.WriteLine("Car added successfully!\n");
        }
        else
        {
            Console.WriteLine("Car collection is full!\n");
        }
    }
    public void ShowCars()
    {
        if (count == 0)
        {
            Console.WriteLine("No cars in the collection.\n");
            return;
        }
        Console.WriteLine("Luxury Car Collection:");
        for (int i = 0; i < count; i++)
        {
            cars[i].DisplayCar();
        }
        Console.WriteLine();
    }

    public void SellCar(string brand, string model)
    {
        for (int i = 0; i < count; i++)
        {
            if (cars[i].GetBrand().Equals(brand, StringComparison.OrdinalIgnoreCase) &&
                cars[i].GetModel().Equals(model, StringComparison.OrdinalIgnoreCase))
            {
                for (int j = i; j < count - 1; j++)
                {
                    cars[j] = cars[j + 1];
                }
                cars[count - 1] = null; 
                count--;
                Console.WriteLine("Car sold successfully!\n");
                return;
            }
        }
        Console.WriteLine("Car not found.\n");
    }
}

class Program
{
    static void Main()
    {
        CarCollection collection = new CarCollection();
        while (true)
        {
            Console.WriteLine(" Luxury Car ");
            Console.WriteLine("1. Add a Car");
            Console.WriteLine("2. View Cars");
            Console.WriteLine("3. Sell a Car");
            Console.WriteLine("4. Exit");
            Console.Write("Select an option: ");
            string choice = Console.ReadLine();
            Console.WriteLine();

            switch (choice)
            {
                case "1":
                    Console.Write("Enter Brand: ");
                    string brand = Console.ReadLine();
                    Console.Write("Enter Model: ");
                    string model = Console.ReadLine();
                    Console.Write("Enter Year: ");
                    int year = int.Parse(Console.ReadLine());
                    Console.Write("Enter Type (Sedan, SUV, Sports, Classic): ");
                    string type = Console.ReadLine();

                    collection.AddCar(brand, model, year, type);
                    break;

                case "2":
                    collection.ShowCars();
                    break;

                case "3":
                    Console.Write("Enter Brand to sell: ");
                    string sellBrand = Console.ReadLine();
                    Console.Write("Enter Model to sell: ");
                    string sellModel = Console.ReadLine();

                    collection.SellCar(sellBrand, sellModel);
                    break;

                case "4":
                    Console.WriteLine("Exiting program...");
                    return;

                default:
                    Console.WriteLine("Invalid choice, try again.\n");
                    break;
            }
        }
    }
}
