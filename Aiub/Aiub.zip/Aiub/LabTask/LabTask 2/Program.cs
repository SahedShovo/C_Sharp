﻿using System;

namespace AnimalShelter
{
    
    class Animal
    {
        private string name;
        private int age;
        private string breed;

        
        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public int Age
        {
            get { return age; }
            set { age = value; }
        }

        public string Breed
        {
            get { return breed; }
            set { breed = value; }
        }

        
        public void DisplayInfo()
        {
            Console.WriteLine($"Name: {Name}");
            Console.WriteLine($"Age: {Age}");
            Console.WriteLine($"Breed: {Breed}");
        }
    }

    class Dog : Animal
    {
        private bool isTrained;

       
        public bool IsTrained
        {
            get { return isTrained; }
            set { isTrained = value; }
        }

        public void DisplayDogInfo()
        {
            DisplayInfo();
            Console.WriteLine($"Is Trained: {IsTrained}");
        }

        public void Woof()
        {
            Console.WriteLine("Woof! Woof!");
        }
    }

    class Cat : Animal
    {
        private bool isIndoor;

       
        public bool IsIndoor
        {
            get { return isIndoor; }
            set { isIndoor = value; }
        }

        
        public void DisplayCatInfo()
        {
            DisplayInfo();
            Console.WriteLine($"Is Indoor: {IsIndoor}");
        }

        public void Meow()
        {
            Console.WriteLine("Meow!");
        }
    }

    
    class Program
    {
        static void Main(string[] args)
        {
            Animal[] animals = new Animal[100];
            int count = 0; 
            char option;
            bool continueRunning = true;

            do
            {
                Console.WriteLine(".......... Animal Shelter Menu ..........");
                Console.WriteLine("Add Dog ........... Press 1");
                Console.WriteLine("Add Cat ........... Press 2");
                Console.WriteLine("Show All Animals .. Press 3");
                Console.WriteLine("Woof (for Dogs) ... Press 4");
                Console.WriteLine("Meow (for Cats) ... Press 5");
                Console.WriteLine("Exit ............... Press 0");

                Console.Write("\nChoice: ");
                option = Convert.ToChar(Console.ReadLine());

                switch (option)
                {
                    case '1':
                        if (count < animals.Length)
                        {
                            Dog dog = new Dog();
                            Console.Write("Enter Dog's Name: ");
                            dog.Name = Console.ReadLine();
                            Console.Write("Enter Dog's Age: ");
                            dog.Age = int.Parse(Console.ReadLine());
                            Console.Write("Enter Dog's Breed: ");
                            dog.Breed = Console.ReadLine();
                            Console.Write("Is the Dog Trained (true/false): ");
                            dog.IsTrained = bool.Parse(Console.ReadLine());

                            animals[count] = dog;
                            count++;
                            Console.WriteLine("Dog Added Successfully!");
                        }
                        else
                        {
                            Console.WriteLine("Shelter is full!");
                        }
                        break;

                    case '2': 
                        if (count < animals.Length)
                        {
                            Cat cat = new Cat();
                            Console.Write("Enter Cat's Name: ");
                            cat.Name = Console.ReadLine();
                            Console.Write("Enter Cat's Age: ");
                            cat.Age = int.Parse(Console.ReadLine());
                            Console.Write("Enter Cat's Breed: ");
                            cat.Breed = Console.ReadLine();
                            Console.Write("Is the Cat Indoor (true/false): ");
                            cat.IsIndoor = bool.Parse(Console.ReadLine());

                            animals[count] = cat;
                            count++;
                            Console.WriteLine("Cat Added Successfully!");
                        }
                        else
                        {
                            Console.WriteLine("Shelter is full!");
                        }
                        break;

                    case '3':
                        if (count == 0)
                        {
                            Console.WriteLine("No animals in the shelter.");
                        }
                        else
                        {
                            for (int i = 0; i < count; i++)
                            {
                                Console.WriteLine($"Animal {i + 1}:");
                                animals[i].DisplayInfo();

                               
                                if (animals[i] is Dog dog)
                                {
                                    dog.DisplayDogInfo();
                                }
                                else if (animals[i] is Cat cat)
                                {
                                    cat.DisplayCatInfo();
                                }
                                Console.WriteLine();
                            }
                        }
                        break;

                    case '4': 
                        Console.Write("Enter the Dog's ID to Woof: ");
                        int dogId = int.Parse(Console.ReadLine()) - 1;
                        if (dogId >= 0 && dogId < count && animals[dogId] is Dog dogToWoof)
                        {
                            dogToWoof.Woof();
                        }
                        else
                        {
                            Console.WriteLine("Invalid Dog ID or this is not a Dog.");
                        }
                        break;

                    case '5': 
                        Console.Write("Enter the Cat's ID to Meow: ");
                        int catId = int.Parse(Console.ReadLine()) - 1;
                        if (catId >= 0 && catId < count && animals[catId] is Cat catToMeow)
                        {
                            catToMeow.Meow();
                        }
                        else
                        {
                            Console.WriteLine("Invalid Cat ID or this is not a Cat.");
                        }
                        break;

                    case '0': 
                        Console.WriteLine("Exiting...");
                        continueRunning = false;
                        break;

                    default:
                        Console.WriteLine("Invalid Option!");
                        break;
                        
                }
            }
            while (continueRunning);
        }
    }
}
