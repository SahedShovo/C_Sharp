﻿using System;

namespace Fr
{
    class Food
    {
        private string name;
        private string type;

        public string Name
        {
            get { return name; }
            set { name = value; }
        }
        public string Type
        {
            get { return type;}
            set { type = value;}
        }
        public virtual void taste()
        {
            Console.WriteLine($"Name: {Name}");
            Console.WriteLine($"Type: {Type}");
        }
    }

    class Burger : Food
    {
        public override void taste()
        {
            base.taste();
            Console.WriteLine("Spicy");
        }
    }

    class Drink:Food{
        public override void taste()
        {
            base.taste();
            Console.WriteLine($"Lemon");
            
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            
            Burger b = new Burger();
            Console.Write($"Enter a Burger Name :");
            b.Name = Console.ReadLine();
            Console.Write($"Enter Burger Type :");
            b.Type = Console.ReadLine();
            b.taste();
            Console.WriteLine();
            Drink d = new Drink();
            Console.Write($"Enter a Drinks Name :");
            d.Name = Console.ReadLine();
            Console.Write($"Enter a Type Name :");
            d.Type =Console.ReadLine();
            d.taste();
        }
    }
}
