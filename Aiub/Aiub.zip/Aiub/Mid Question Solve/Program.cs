﻿using System.Diagnostics;
using System.Net.Quic;

namespace BPL
{
    class Player{
        protected string player_Id;
        protected string Player_Name;
        protected string team_Name;
        public Player(string id,string name,string team){
            player_Id=id;
            Player_Name=name;
            team_Name=team;
        }
        public void ShowInfo(){
            Console.WriteLine($"Player Id {player_Id}\nPlayer Name{Player_Name}");
            Console.WriteLine($"Team Name{team_Name}");
        }
        public virtual void PlayerPerfomance(){

        }
    }
    class Batsman:Player{
        int total_run;
        double bating_avrage;
        int high_score;
        public Batsman(string id,string name,string team,int tr,double b_a,int h_s):base(id,name,team){
            total_run=tr;
            bating_avrage=b_a;
            high_score=h_s;
        }
        public void ShowInfo(){
            base.ShowInfo();
            Console.WriteLine($"Total Run:{total_run}\nBating Avrage :{bating_avrage}\nHigh Score :{high_score}");
            PlayerPerfomance();
        }
        public override void PlayerPerfomance()
        {
           if(bating_avrage>50){
            Console.WriteLine($"Aligible Best Batasman AWard ");
           }
           else{
            Console.WriteLine($"Not Aligible for Award ");
           }
        }
    }
    class Bowler:Player{
        int total_wicket;
        double bowling_avrage;
        public Bowler(string id,string name,string team,int t_w,double b_w):base(id,name,team){
            total_wicket=t_w;
            bowling_avrage=b_w;
        }
        public void ShowInfo(){
            base.ShowInfo();
            Console.WriteLine($"Total Wicket :{total_wicket}\nBowling Avrage :{bowling_avrage}");
            PlayerPerfomance();
        }
        public override void PlayerPerfomance()
        {
            if(total_wicket>100){
                Console.WriteLine($"Award Eligibility");
                
            }
            else{
                Console.WriteLine($"No Award ");
            }
        }
    }
    class AllRounder:Player{
        int totalrun;
        int totalWicket;
        public AllRounder(string id,string name,string team,int tr,int tw):base(id,name,team){
            totalrun=tr;
            totalWicket=tw;
        }
        public void ShowInfo(){
            base.ShowInfo();
            Console.WriteLine($"Total Run :{totalrun}\nTotal Wicket :{totalWicket}");
            PlayerPerfomance();
        }
        public override void PlayerPerfomance()
        {
            if(totalrun>100 && totalWicket>50){
                Console.WriteLine($"Award Eligibility");
            }
            else{
                Console.WriteLine($"Not Award Eligibility");
                
            }

        }
    }
    class Program
{
    static void Main()
    {
        Player[] players = new Player[4];
        players[0] = new Batsman("P-1", "Tom Latham", "NZ", 6789, 57.3, 183);
        players[1] = new Bowler("P-2", "Taskin Ahmed", "BD", 184, 23.2);
        players[2] = new AllRounder("P-3", "Glenn Maxwell", "AJ5", 7590, 98);
        players[3] = new AllRounder("P-4", "Sam Curran", "Eng", 781, 60);

        foreach (Player player in players)
        {
            player.ShowInfo();
            Console.WriteLine();
        }
    }
}
}