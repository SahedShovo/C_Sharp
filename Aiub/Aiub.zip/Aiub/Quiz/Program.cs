﻿using System;
/*class Program{
    static void Main(){
        int a,b;
        char o;
        string c;
        do
        {
            Console.WriteLine($"Enter a Equation");
            string[] value=Console.ReadLine().Split();
            a=int.Parse(value[0]);
            o=char.Parse(value[1]);
            b=int.Parse(value[2]);
            switch(o){
                case'+':
                Console.WriteLine($"{a}  {o}  {b} :{a+b}");
                break;
                case'-':
                Console.WriteLine($"{a}  {o}  {b} :{a-b}");
                break;
                case'*':
                Console.WriteLine($"{a}  {o}  {b} :{a*b}");
                break;
                case'/':
                Console.WriteLine($"{a}  {o}  {b} :{a/b}");
                break;
                case'%':
                Console.WriteLine($"{a}  {o}  {b} :{a%b}");
                break;
            }
            Console.Write($"Choice :");
            c=Console.ReadLine();
            
            
        } 
        while (c=="Yes");
    }
}
class Program{
    struct Toy{
        public string name;
        public double price;
        public int quantity;
    }
    static void Main(){
        char o;
        Toy [] toy= new Toy[100];
        bool c=true;
        toy[0].name="Car";
        toy[0].price=12.0D;
        toy[0].quantity=5;
        toy[1].name="Doll";
        toy[1].price=10.0D;
        toy[1].quantity=2;
        int count=2;
        Console.WriteLine($".....Menu....");
        Console.WriteLine($"Add New Toy ...... Press 1");
        Console.WriteLine($"Delate a Toy ..... Press 2");
        Console.WriteLine($"Show All Toy ..... Press 3");
        Console.WriteLine($"...Exit...Press 0");
        do{
        Console.WriteLine($"Choice :");
        o=Convert.ToChar(Console.ReadLine());
        switch (o)
        {
            case '1':
            Console.WriteLine($"Enter a Toy Name :");
            toy[count].name=Console.ReadLine();
            Console.WriteLine($"Enter Toy Price :");
            toy[count].price=double.Parse(Console.ReadLine());
            Console.WriteLine($"Enter Toy Quantity :");
            toy[count].quantity=int.Parse(Console.ReadLine());
            count++;
            Console.WriteLine($"Toy Add SuccessFully !");
            break;

            case '2':
            Console.WriteLine($"Whitch Toy You Want To Delate !");
            int x=int.Parse(Console.ReadLine());
            Console.WriteLine($"{toy[x-1].name} {toy[x-1].price} {toy[x-1].quantity}");
            Console.WriteLine($"Remove From The Toy List !");
            Console.WriteLine($"");
            for (int i = x; i < count; i++)
            {
                toy[i-1]=toy[i];
                count--;
            }
            break;
            case '3':
            for (int i = 0; i < count; i++)
            {
                Console.WriteLine($"Toy :{i+1}");
                Console.WriteLine($"Toy Name :{toy[i].name}");
                Console.WriteLine($"Toy Price :{toy[i].price}");
                Console.WriteLine($"Toy Quantity :{toy[i].quantity}");
            }
             break;
            case '0':
            Console.WriteLine($"Exit");
            c=false;
            break;
            default:
            Console.WriteLine($"Invalid Openion ");
            break;
            
        }
            
        } while (c==true);
    }
}
class Car{
    private string brand;
    private string model;
    private int year;
    private string type;

    protected string Brand{
        get{return brand;}
        set{brand=value;}
    }
    public string Model{
        get{return model;}
        set{model=value;}        
    }
    public int Year{
        get{return year;}
        set{year=value;}
    }
    public string Type{
        get{return type;}
        set{type=value;}
    }

    class Program:Car{
        static void Main(){
            Car[] car=new Car[100];
            char o;
            bool c=true;

            car[0]=new Car{Brand="Honda",Model="R37",Year=2025,Type="Sedan"};
            car[1]=new Car{Brand="Audi",Model="r5",Year=2024,Type="Boom"};

            int count=2;
            Console.WriteLine($"...Menu...");
            Console.WriteLine($"Add New Car .... Press 1 ");
            Console.WriteLine($"Show All Cars .... Press 2 ");
            Console.WriteLine($"Delate Car .... Press 3 ");
            Console.WriteLine($"Exit .... Press 4 ");
           do{
            Console.WriteLine($"Choice");
            o=Convert.ToChar(Console.ReadLine());
           {
            switch (o)
            {
                case '1':
                car[count]=new Car();
                Console.Write($"Enter a Car Brand Name :");
                car[count].Brand=Console.ReadLine();
                Console.Write($"Enter a Car Model Name :");
                car[count].Model=Console.ReadLine();
                Console.Write($"Enter a Car Year :");
                car[count].Year=int.Parse(Console.ReadLine());
                Console.Write($"Enter a Car Type :");
                car[count].Type=Console.ReadLine();
                count++;
                Console.WriteLine($"Add SuccessFully ");
                break;
                case '2':
                if(count==0){
                    Console.WriteLine($"NO Car Collection !");
                }
                else{
                    for (int i = 0; i < count; i++)
                    {
                        Console.WriteLine($"Car No :{i+1}");
                        Console.WriteLine($"{car[i].Brand} {car[i].Model} {car[i].Year} {car[i].Type}");
                        Console.WriteLine($"");
                    }
                }
                break;
                case '3':
                Console.WriteLine($"Whitch Collection You Want To Delate ?");
                int x=int.Parse(Console.ReadLine());
                if(x<=count){
                    Console.WriteLine($"{car[x-1].Brand} {car[x-1].Model} {car[x-1].Year} {car[x-1].Type}");
                    Console.WriteLine($"Remove The Car Cullection!");
                    for (int i = x; i < count; i++)
                    {
                        car[i-1]=car[i];
                    }
                    count--;
                }
                else
                {
                    Console.WriteLine($"Invalid Car ID !! ");
                }
                break;
                case'4':
                Console.WriteLine($"Exit !!");
                c=false;
                break;
                default:
                Console.WriteLine($"Invalid Option!!");
                break;
            }

           } 

           }
           while (c==true);

        }
    }
}
using System;

class Employee
{
    // Encapsulation with private fields and public properties
    private int employeeID;
    private string name;
    private string position;
    private double salary;

    // Constructor to initialize employee's information
    public Employee(int id, string name, string position, double salary)
    {
        this.employeeID = id;
        this.name = name;
        this.position = position;
        this.salary = salary;
    }

    // Public Properties to access private fields
    public int EmployeeID
    {
        get { return employeeID; }
        set { employeeID = value; }
    }

    public string Name
    {
        get { return name; }
        set { name = value; }
    }

    public string Position
    {
        get { return position; }
        set { position = value; }
    }

    public double Salary
    {
        get { return salary; }
        set { salary = value; }
    }

    // Function to calculate bonus (10% of salary)
    public double CalculateBonus()
    {
        return salary * 0.10;
    }

    // Method to display employee details
    public void DisplayInfo()
    {
        Console.WriteLine($"Employee ID: {employeeID}");
        Console.WriteLine($"Name: {name}");
        Console.WriteLine($"Position: {position}");
        Console.WriteLine($"Salary: {salary:C}");
    }
}

// Manager class inherits from Employee class
class Manager : Employee
{
    // Additional property for Manager
    private string department;

    // Constructor to initialize Manager-specific data
    public Manager(int id, string name, string position, double salary, string department)
        : base(id, name, position, salary) // Call base class constructor
    {
        this.department = department;
    }

    // Property to access department
    public string Department
    {
        get { return department; }
        set { department = value; }
    }

    // Override method to display additional manager info
    public new void DisplayInfo()
    {
        base.DisplayInfo();  // Call base class DisplayInfo
        Console.WriteLine($"Department: {department}");
    }
}

class Program
{
    static void Main()
    {
        // Create an Employee object
        Employee emp = new Employee(1, "John Doe", "Developer", 5000);
        emp.DisplayInfo();
        Console.WriteLine($"Bonus: {emp.CalculateBonus():C}\n");

        // Create a Manager object
        Manager mgr = new Manager(2, "Jane Smith", "Manager", 8000, "HR");
        mgr.DisplayInfo();
        Console.WriteLine($"Bonus: {mgr.CalculateBonus():C}");
    }
}
using System;

namespace Pack
{
    // Base class A
    public class A
    {
        // 'num' is internal: accessible within the same project/assembly
        internal int num = 15;
    }

    // Class B inherits from A
    public class B : A
    {
        // 'val' is protected internal: accessible in same project and by derived classes
        protected internal int val = 30;
    }
    // Base class Alpha
    public class Alpha
    {
        // Static string shared across all Alpha-derived objects
        // Initialized with "Start "
        protected static string data = "Start ";

        // Constructor of Alpha appends "alpha " to static data
        protected Alpha()
        {
            data += "alpha ";
        }
    }

    // Subclass of Alpha
    class SubAlpha : Alpha
    {
        // Constructor appends "subalpha " after calling base constructor (Alpha)
        public SubAlpha()
        {
            data += "subalpha ";
        }

        // Show current value of static 'data'
        public void ShowData()
        {
            Console.WriteLine(data);
        }
    }

    // Another subclass of Alpha
    public class SubSubAlpha : Alpha
    {
        // Constructor appends "subsubalpha " after calling Alpha()
        public SubSubAlpha()
        {
            data += "subsubalpha ";
        }
        // Print the 'num' field from an object of class A
        public static void DisplayNum(A objA)
        {
            Console.WriteLine(objA.num);
        }

        // Print the 'val' field from an object of class B
        public static void DisplayVal(B objB)
        {
            Console.WriteLine(objB.val);
        }

        // Program starts here
        public static void Main(string[] args)
        {
            // Create object of class A and set num to 40
            A objA = new A();
            objA.num = 40;  // Overrides default value of 15

            // Create object of class B and set val to 50
            B objB = new B();

            objB.val = 50;  // Overrides default value of 30
            // Display objA.num → 40
            DisplayNum(objA);
            // Display objB.num → inherited from A, still 15 (we didn't change it)
            DisplayNum(objB);

            // Display objB.val → 50
            DisplayVal(objB);

            // At this point, no Alpha constructor has been run,
            // so 'data' is still just "Start "
            Console.WriteLine(data);  // Output: Start 

            Console.WriteLine("Determine:");

            // Reset data to a new value
            data = "Reset ";

            // Create SubSubAlpha object
            // This calls:
            // - Alpha() → data = "Reset alpha "
            // - SubSubAlpha() → data = "Reset alpha subsubalpha "
            new SubSubAlpha();

            // Print updated data
            Console.WriteLine(data);  // Output: Reset alpha subsubalpha 

            // Final printouts
            Console.WriteLine("Final data = " + data);       // Output: Final data = Reset alpha subsubalpha 
            Console.WriteLine("Final num = " + objA.num);    // Output: Final num = 40
        }
    }
}*/
using System;
class Program
{
    static void Main(string[] args)
    {
        int[][] myArray = new int[4][];
        myArray[0] = new int[] { 1, 3, 5, 7, 9, -2 };
        myArray[1] = new int[4];
        myArray[2] = new int[] { 2, 4, 6, 8, 5, 3 };
        myArray[3] = new int[4];

        for (int row = 0; row < 4; row += 2)
        {
            for (int column = 1; column < myArray[row].Length; column += 3)
            {
                Console.Write("{0} ", myArray[row][column]);
            }
            Console.WriteLine();
        }
        for (int index = 0; index < myArray[1].Length; index++)
        {
            myArray[1][index] = myArray[0][index + 1] * 2;
        }
        for (int index = 0; index < myArray[3].Length; index++)
        {
            myArray[3][index] = myArray[2][index] + myArray[2][index + 2];
        }
        for (int row = 1; row < 4; row += 2)
        {
            for (int column = 0; column < myArray[row].Length; column++)
            {
                Console.Write("{0} ", myArray[row][column]);
            }
            Console.WriteLine();
        }
    }
}

