﻿using System;
using System.Linq; // Required for Max(), Min(), Sum(), and Average()

public class Myclass
{
    public static void Main(string[] args)
    {
        int[] num = { 1, 2, 3, 4, 5 };

        Console.WriteLine($"Length of the Array : {num.Length}");
        Console.WriteLine($"Rank of the Array : {num.Rank}");
        Console.WriteLine($"Max Value : {num.Max()}");
        Console.WriteLine($"Min Value : {num.Min()}");
        Console.WriteLine($"Sum of Values : {num.Sum()}");
        Console.WriteLine($"Average Value : {num.Average()}");
       
        Console.Write($"Before Sorting :");
        Print(num);
        Array.Sort(num);
        Console.Write($"After Sorting :");
        Print(num);
        Array.Reverse(num);
        Console.Write($"After Reverse :");
        Print(num);
        
        
        Console.ReadKey();
    }
    public static void Print(int [] num){
        foreach (var item in num)
        {
            Console.Write($"{item}");
            
        }
        Console.WriteLine();
        
    }
}
//Length,Rank
//max(),min(),sum(),Avrage(),Sort(),Reverse()
