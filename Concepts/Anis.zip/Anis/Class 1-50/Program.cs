﻿using System;
using System.Threading;

class BirthdayWish
{
    static void Main()
    {
        Console.ForegroundColor = ConsoleColor.Cyan;
        Console.WriteLine("\n🎉🎂 Happy Birthday! 🎂🎉\n");
        Thread.Sleep(1000);

        Console.ForegroundColor = ConsoleColor.Yellow;
        Console.WriteLine("Wishing you a day filled with joy and laughter!\n");
        Thread.Sleep(1000);

        Console.ForegroundColor = ConsoleColor.Green;
        Console.WriteLine("May all your dreams come true. Have a fantastic year ahead! 🎈🎁\n");
        Thread.Sleep(1000);

        Console.ForegroundColor = ConsoleColor.Magenta;
        Console.WriteLine("🎊 Enjoy your special day! 🎊");
        
        Console.ResetColor();


















    /*string studentName;
    int studentAge;
    Console.Write("Enter Student Name:");
    studentName=Console.ReadLine();
    Console.Write("Enter Student Age:");
    studentAge=Convert.ToInt32(Console.ReadLine());
    Console.WriteLine("Student Name :" + studentName);
    Console.WriteLine("Student Age : " + studentAge + " Years old ");
    */








    /*string productNmae="Apple iphone 14 ";
    double productPrice=320.5;
    string catagory="Smart Phone";
    bool Avaliable=true;
    int productSold=5;
    Console.Write("Name :");
     Console.WriteLine(productNmae);
     Console.Write("price :$");
     Console.WriteLine(productPrice);
     Console.WriteLine(catagory);
     Console.WriteLine(Avaliable);
     Console.WriteLine(productSold);






    string fullName = "Sahed Ahmed";
    int age=22;
    double cgpa=3.30;
    bool isRegistered=true;
    char bloodGroup='A';
     Console.WriteLine(fullName);
     Console.WriteLine(age);
     Console.WriteLine(cgpa);
     Console.WriteLine(isRegistered);
     Console.WriteLine(bloodGroup);
     fullName="Nusrat Jahan";
     Console.WriteLine(fullName);
     */
   }
}