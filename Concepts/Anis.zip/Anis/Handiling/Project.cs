using System;

public class MyClass
{
    public static void Main(string[] args)
    {
        Console.WriteLine("Welcome to Calculator App");
        try
        {
            int num1 = ReadIntInput("Num1");
            int num2 = ReadIntInput("Num2");

            if (num2 > 1000)
            {
                throw new ArgumentException("Number 2 can't be greater than 1000.");
            }

            int result = num1 / num2;
            Console.WriteLine($"Result: {result}");
        }
        catch (Exception e)
        {
            Console.WriteLine($"Error Occurred: {e.Message}");
        }
        finally
        {
            Console.WriteLine("Goodbye!!!");
        }
    }

    static int ReadIntInput(string prompt)
    {
        while (true)
        {
            Console.Write($"Enter {prompt} = ");
            string input = Console.ReadLine() ?? "";
            if (!int.TryParse(input,out int result)||string.IsNullOrEmpty(input))
            {
                Console.WriteLine($"Invalid input Please enter a Valid int !");
                continue;  // Ask for input again
            }
           return result;

        }
    }
}
