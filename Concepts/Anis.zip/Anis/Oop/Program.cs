﻿using System.Dynamic;
using System.Security.Cryptography.X509Certificates;
public class Student{
        public int age;
    }


//class Person
//{
    


    /*
    private string name;
    private int age;

    public string Name{
        get{return name;}
        set{name=value;}
    }
    public int Age{
        get{return age;}
        set{age=value;}
    }*/


    /*public Person(){//defoult constractor 
        name="Ahmed";
        age=23;
    }
    public Person(string n,int a){//Paramiterized constractor 
        name=n;
        age=a;
    }
    public void Display(){
        Console.WriteLine($"Name : {name}\n Age : {age}\n");
    }*/
//}
class Test{
    public static void Main(string[] args)
    {
        Student s1=new Student();
        s1.age=30;
        Console.WriteLine($"{s1.age}");






       /* Person p1=new Person();
        p1.Name="Sahed Ahemd";
        p1.Age=23;
        Console.WriteLine($"Name : {p1.Name}\nAge : {p1.Age}\n");*/
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        /*Person p1=new Person("Sahed Ahemd ",21);
        p1.Display();
        Person p2=new Person("Nusrat Jahan ",20);
        p2.Display();
        Person p3=new Person();
        p3.Display();*/
















        /*Person p1=new Person();
        p1.name="Sahed Ahmed";
        p1.age=23;
        Console.WriteLine("Person 1:");
        Console.WriteLine($"Namae:{p1.name} \nAge :{p1.age} ");
        Person p2=new Person();
        p2.name="Nusrat Jahan";
        p2.age=21;
        Console.WriteLine("Person 2:");
        Console.WriteLine($"Namae:{p2.name} \nAge :{p2.age} ");
        */
    }
}