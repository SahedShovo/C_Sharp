﻿using System;
using System.Windows.Forms;

class Program
{
    static void Main()
    {
        Application.EnableVisualStyles();
        Application.SetCompatibleTextRenderingDefault(false);
        Application.Run(new MainForm());
    }
}

public class MainForm : Form
{
    public MainForm()
    {
        Text = "My First Windows Forms App";
        Width = 400;
        Height = 300;

        Button button = new Button();
        button.Text = "Click Me!";
        button.Left = 150;
        button.Top = 100;
        button.Click += (sender, e) => MessageBox.Show("Hello, Windows Forms!");

        Controls.Add(button);
    }
}
