﻿using System;

public class Myclass
{
    public static void Main(string[] args)
    {
        string text = "Sahed Ahmed Shovo";

        Console.WriteLine($"Length of String : {text.Length}");
        Console.WriteLine($"0 Index From String : {text[0]}");

        bool is_empty = string.IsNullOrEmpty(text); // ✅ Fixed Syntax
        Console.WriteLine($"Is String Empty Or Null? {is_empty}");

        string upper = text.ToUpper();
        Console.WriteLine($"Upper String : {upper}");

        string lower = text.ToLower();
        Console.WriteLine($"Lower String : {lower}");

        string trimmedString = text.Trim();
        Console.WriteLine($"Trimmed String : {trimmedString}");
    }
}
