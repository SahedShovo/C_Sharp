﻿public class Test
{
    public static void Main(string[] args)
    {
       //string n1,n2,n3;
       //n1="Sahed";
       //n2="Nusrat";
       //n3="Shinha";
       string [] name={"Sahed","Nusrat","Shinha","Nahid","Shihab"};
       for (int i = 0; i < name.Length; i++)
       {
        Console.WriteLine(name[i]);
       }
       Console.WriteLine($"-------------");
       
       foreach(string n in name){
        Console.WriteLine(n);
       }

    }
}
