using System;

public class Student
{
    public string Name { get; private set; }
    public DateTime DateOfBirth { get; private set; }
    public string? RollNumber { get; private set; }

    public Student(string name, DateTime dateOfBirth, string rollNumber)
    {
        ValidateInputs(name, dateOfBirth, rollNumber);
        Name = name;
        DateOfBirth = dateOfBirth;
        RollNumber = rollNumber;
    }
    private static void ValidateInputs(string name, DateTime dateOfBirth, string rollNumber)
    {
        if (dateOfBirth > DateTime.Now)
        {
            throw new ArgumentException("Date of Birth can't be in the future!");
        }
        if (string.IsNullOrWhiteSpace(name))
        {
            throw new ArgumentException("Name can't be null or empty!");
        }
        if (string.IsNullOrWhiteSpace(rollNumber))
        {
            throw new ArgumentException("Roll Number can't be null or empty!");
        }
        if (dateOfBirth == default)
        {
            throw new ArgumentException("Date of Birth Can't be Null!");
        }
    }

    private int CalculateAge()
    {
        int age = DateTime.Now.Year - DateOfBirth.Year;

        return DateTime.Now < DateOfBirth.AddYears(age)?age--:age;
    }
    public int Age => CalculateAge(); // Expression-bodied property

    public void Print()
    {
        Console.WriteLine($"Name: {Name}, Date of Birth: {DateOfBirth.ToShortDateString()}, Roll Number: {RollNumber}, Age: {Age}");
    }
}

public class MyClass
{
    public static void Main1(string[] args)
    {
        try
        {
            Student student1 = new Student("Sahed Ahmed", new DateTime(2001, 5, 28), "Cse101");
            Student student2 = new Student("Nusrat Jahan", new DateTime(2003, 3, 23), "Eng101");

            // Display Student Details 
            Console.WriteLine("Student Details:");
            Console.WriteLine("------------------");
            student1.Print();
            student2.Print();
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error: {ex.Message}");
        }
    }
}
