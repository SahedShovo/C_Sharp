﻿using System;
class Program{
    static void Main(){
        int [] number ={ 1,2,3,4,5};
        Console.WriteLine($"Number 1 : {number[0]}");
        Console.WriteLine($"Number 2 : {number[1]}");
        
        Console.WriteLine($"All Numbers in The Array ");
        
        for(int i=0;i<number.Length;i++){
            Console.Write($"{number[i]} ");
        }
    }
}