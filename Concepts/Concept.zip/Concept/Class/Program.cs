﻿using System;

class Car
{
    public string Model;
    public int Year;

    // Default Constructor
    public Car()
    {
        Model = "Unknown";
        Year = 0;
    }

    // Parameterized Constructor
    public Car(string model, int year)
    {
        Model = model;
        Year = year;
    }

    public void ShowInfo()
    {
        Console.WriteLine($"Car Model: {Model}, Year: {Year}");
    }
}

class Program
{
    static void Main()
    {
        Car car1 = new Car(); // Calls default constructor
        car1.ShowInfo();  

        Car car2 = new Car("Ford", 2022); // Calls parameterized constructor
        car2.ShowInfo();  
    }
}
