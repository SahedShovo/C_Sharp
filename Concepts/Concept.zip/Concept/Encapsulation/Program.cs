﻿using System;
class Car{
    private string name;
    private int speed;

   public string Name{
    get{return name;}
    set{name=value;}
   }
   public int Speed{
    get{return speed;}
    set{
        if(value>=0){
            speed=value;
        }
        else{
            Console.WriteLine($"Speed Can't Be Negative !");
            speed=0;
        }
    }
   }
   public Car(string carname,int carspeed){
        Name=carname;
        Speed=carspeed;
    }
    public void Display(){
        Console.WriteLine($"Car Name :{name}\nCar Speed :{speed}");
    }
}
class Program{
    static void Main(){
        Car c1=new Car("Toyota",120);
        c1.Display();
        Car c2=new Car("Bmw", - 10);
        c2.Display();
    }
}