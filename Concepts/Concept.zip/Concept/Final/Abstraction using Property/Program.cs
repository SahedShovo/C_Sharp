﻿public abstract class Animal
{
    public Animal(string name)
    {
        Name = name;
    }
    public string Name { get; set; }

    public abstract void AnimalSound();
    public void Sleep()
    {
        System.Console.WriteLine("zzz");
    }
    public override string ToString()
    {
        return Name; 
    }
}

public class Dog : Animal
{
    public Dog(string name) : base(name)
    {
        Name=name;
    }

    public override void AnimalSound()
    {
        System.Console.WriteLine("bww bww");
    }
}
class Program
{
    static void Main()
    {
        Dog myDog = new Dog("pie");  
        Console.WriteLine(myDog.ToString());  
        myDog.AnimalSound(); 
    }
}
