﻿abstract class sports {
    public abstract void duration();
    public void gender(){
        Console.WriteLine("...");
    }
class cricket :sports{
    public override void duration()
    {
        Console.WriteLine("5 Days");
    }
}
class 
class program {
    
    static void  Main(string[] args)
    {
        const int a= 20;
        Console.WriteLine(a);
        cricket c1=new cricket();
        c1.duration();
        c1.gender();
    }
}
}