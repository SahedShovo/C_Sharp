﻿using System;
class Program {
    static int Add(int a,int b){
        return a+b;
    }
    static void Main(){
        int result=Add(10,20);
        Console.WriteLine($"Result :{result} ");
    }
}