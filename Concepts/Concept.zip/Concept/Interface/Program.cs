﻿using System;

// Define the interface
interface IPen
{
    string Color { get; set; }
    bool Open();
    bool Close();
    void Write(string text);
}

// Implement the interface in Cello class
class Cello : IPen
{
    public string Color { get; set; }

    private bool isOpen = false;

    public bool Open()
    {
        isOpen = true;
        Console.WriteLine("Cello pen is now open.");
        return isOpen;
    }

    public bool Close()
    {
        isOpen = false;
        Console.WriteLine("Cello pen is now closed.");
        return isOpen;
    }

    public void Write(string text)
    {
        if (isOpen)
        {
            Console.WriteLine($"Cello [{Color}] writes: {text}");
        }
        else
        {
            Console.WriteLine("Cannot write. Pen is closed.");
        }
    }
}

// Main class
class Program
{
    static void Main()
    {
        IPen pen = new Cello();        // Polymorphic declaration
        pen.Color = "Blue";            // Set property directly

        Console.WriteLine("Pen color is set to: " + pen.Color);

        pen.Write("Trying to write while pen is closed.");
        pen.Open();
        pen.Write("Hello, Interface World!");
        pen.Close();
        pen.Write("This won't be written.");
    }
}
