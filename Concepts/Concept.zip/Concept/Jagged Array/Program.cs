﻿using System;
using System.Diagnostics.Contracts;

public class Pogram
{
    public static void Main(string[] args)
    {
        string[] Friend=new string[3];
        Friend[0]="Rahim";
        Friend[1]="Karim";
        Friend[2]="Jasim";
        string[][] Breakfast=new string[3][];
        Breakfast[0]=new string [2];
        Breakfast[1]=new string [2];
        Breakfast[2]=new string [1];

        Breakfast[0][0]="Bread";
        Breakfast[0][1]="Orange Juce";

        Breakfast[1][0]="Fish";
        Breakfast[1][1]="Chicken";

        Breakfast[2][0]="Pasta";

        for(int i=0;i<Breakfast.Length;i++){

            Console.WriteLine($"{Friend[i]}");
            Console.WriteLine($"----------------------");
            
            for(int j=0;j<Breakfast[i].Length;j++){
                Console.WriteLine($"{Breakfast[i][j]}");
            }
            Console.WriteLine();
            
        }
    }
}
