﻿using System;

namespace NullableTypeDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            // Using nullable types
            int? a = null;                // Nullable int using '?' operator
            var b = 45;                   // Implicitly typed int (not nullable)
            var c = "sa";                 // Implicitly typed string
            c = "SS";                     // Reassigning the string

            // Checking if 'a' has a value before accessing it
            if (a.HasValue)
            {
                Console.WriteLine("a has a value: " + a.Value);
            }
            else
            {
                Console.WriteLine("a is null");
            }

            // You can also use the null-coalescing operator '??'
            int result = a ?? -1; // If a is null, result becomes -1
            Console.WriteLine("Value of 'a' or default: " + result);

            // Output other variables
            Console.WriteLine("b = " + b);
            Console.WriteLine("c = " + c);

            // Assign value to 'a' and test again
            a = 100;

            if (a.HasValue)
            {
                Console.WriteLine("Now a has a value: " + a.Value);
            }

            // Using GetValueOrDefault to get value or default (0 for int)
            Console.WriteLine("a.GetValueOrDefault() = " + a.GetValueOrDefault());
        }
    }
}
