﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
 
namespace Poly2
{
    class food
    {
       public virtual void taste ()
        {
            Console.WriteLine("sour ");
        }
    }
    class burger:food
    {
       public override void taste()
        {
            Console.WriteLine("Spicy ");
        }
    }
    class drinks:food
    {
       public override void taste()
        {
            base.taste();
            Console.WriteLine("Mint ");
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            food f = new food();
            f.taste();
            food f1 = new burger();
            f1.taste();
            food f2 = new drinks();
            f2.taste();
        }
    }
}