﻿namespace Polymorphism
{
    class Program
    {
        int sum(int a,int b){
            return a+b;
        }
        double sum(double c, double d){
            return c+d;
        }
        string sum(string e,string f){
            return e+f;
        }
        static void Main(){
            Program p=new Program();
            Console.WriteLine($"{p.sum(1,7)}");
            Console.WriteLine($"{p.sum(1.1,7)}");
            Console.WriteLine($"{p.sum("Hello","World")}");
        }
    }
}
