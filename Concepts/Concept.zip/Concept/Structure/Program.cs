﻿using System ;
struct Person
{
    public string Name;
    public int Age;

    public Person(string name,int age){
        Name=name;
        Age=age;
    }
    public void Display(){
        Console.WriteLine($"Name : {Name} \nAge : {Age} ");
    }
}
class Program {
    static void Main(){
        Person p1=new Person();
        p1.Name="Sahed Ahmed ";
        p1.Age=20;
        p1.Display();
    }

}