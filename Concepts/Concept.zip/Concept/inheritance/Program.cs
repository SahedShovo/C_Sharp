﻿/*class student{
    private string name;
    private string id;

    public string name{
        set{return name =value;}
        set{name=value;}
    }
     public string id{
        set{return id =value};
        set{id=value};
    }
}
class exstudent{
    private string pussingYear;
    public int pussingYear{
        get{return pussingYear;}
       set{pussingYear=value;}
    }

}
class convertstudent:student{
    private int serialNO;
    public int serialNO{
        get{return serialNO;}
        set{serialNO=value;}
    }
}
class Program
{
    public static void Main(string[] args)
    {
        exstudent es=new exstudent();
        es name="sahed";
        es id="123";
        es pussingYear=2019;
        Console.WriteLine("Student Name "+es.Name);
        Console.WriteLine("Student id :"+es.id);
        Console.WriteLine("Student Year :"+es.pussingYear);
        
    }
}*/
/*using System;

class Program
{
    public string name;
    public string color;
    public Program()
    {
        Console.WriteLine("Default Constructor Called");
        name = "Unknown"; 
        color = "Unknown";
    }

   
    public Program(string name, string color)
    {
        Console.WriteLine("Parameterized Constructor Called");
        this.name = name;
        this.color = color;
    }

    public static void Main(string[] args)
    {
        Program p1 = new Program();
        Program p2 = new Program("Mango", "Red"); 

        Console.WriteLine($"Object 1: Name = {p1.name}, Color = {p1.color}");
        Console.WriteLine($"Object 2: Name = {p2.name}, Color = {p2.color}");
    }
}*/

using System;

class Parent
{
    private string message;

    public void SetMessage(string newMessage)
    {
        message = newMessage;
    }

    public string GetMessage()
    {
        return message;
    }
}

class Child : Parent
{
    private int serialNO;

    public void SetSerialNO(int no)
    {
        serialNO = no;
    }

    public int GetSerialNO()
    {
        return serialNO;
    }
}

class Program
{
    static void Main()
    {
        Child childObj = new Child();

        childObj.SetMessage("Child Class ");
        childObj.SetSerialNO(101);

        Console.WriteLine("Child Object Message: " + childObj.GetMessage());
        Console.WriteLine("Child Serial Number: " + childObj.GetSerialNO());
    }
}
