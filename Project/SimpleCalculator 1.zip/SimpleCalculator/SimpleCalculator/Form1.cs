﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SimpleCalculator
{
    public partial class Form1 : Form
    {
        double resultValue;
        string operation;
        bool isOperationPerformd;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button12_Click(object sender, EventArgs e)
        {
            if (resultTextBox1.Text== "0" || (isOperationPerformd)) resultTextBox1.Clear();

            Button button = (Button) sender;

            resultTextBox1.Text = resultTextBox1.Text + button.Text;
            isOperationPerformd= false;
        }

        private void AcButton1_Click(object sender, EventArgs e)
        {
            resultTextBox1.Text= "0";
        }

        private void operator_click(object sender, EventArgs e)
        {
            Button button = (Button)sender;
            operation = button.Text;
            resultValue = double.Parse(resultTextBox1.Text);
            isOperationPerformd=true;
            label2.Text = resultValue + " " + operation;

        }

        private void equalButton_Click(object sender, EventArgs e)
        {
            switch (operation) 
            
            {
                case "+":
                    resultTextBox1.Text = (resultValue + double.Parse(resultTextBox1.Text)).ToString();
                    break;
                case "-":
                    resultTextBox1.Text = (resultValue - double.Parse(resultTextBox1.Text)).ToString();
                    break;
                case "*":
                    resultTextBox1.Text = (resultValue * double.Parse(resultTextBox1.Text)).ToString();
                    break;
                case "/":
                    resultTextBox1.Text = (resultValue / double.Parse(resultTextBox1.Text)).ToString();
                    break;
                case "%":
                    resultTextBox1.Text = (resultValue % double.Parse(resultTextBox1.Text)).ToString();
                    break;
                default:
                    break;
              
            }
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
}
